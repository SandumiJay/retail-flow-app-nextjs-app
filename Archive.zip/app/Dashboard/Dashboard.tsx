import { NavLink } from "@mantine/core"; // eslint-disable-line
import React from "react";
import { IconChevronRight, IconGauge, IconHome2 } from "@tabler/icons-react"; // eslint-disable-line
interface DashboardProps {
  user: {
    name: string;
    role: string;
  };
}
const Dashboard: React.FC<DashboardProps> = () => {
  return (
    <div>
         
    </div>
  );
};

export default Dashboard;
