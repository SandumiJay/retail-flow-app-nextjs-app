const config ={
    OUT_OF_STOCK : 0,
    LOW_STOCK : 50,
    SSH_HOST:'162.213.255.13' ,
    SSH_PORT: '21098',
    SSH_USER:'saysmulx',
    SSH_PASSWORD : 'FzDjuoOmhmuW',
    DB_HOST :'127.0.0.1',
    DB_PORT :'3306',
    DB_USERNAME:'saysmulx_root',
    DB_PASSWORD:'1QAZ2wsx@2024',
    LOCAL_DB_USERNAME:'root',
    LOCAL_DB_PASSWORD:'1QAZ2wsx@'

}

export default config